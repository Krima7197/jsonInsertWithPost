

import UIKit

class ViewController: UIViewController,UIImagePickerControllerDelegate,UINavigationControllerDelegate {

    @IBOutlet weak var address: UITextField!
    @IBOutlet weak var img: UIImageView!
    @IBOutlet weak var mon: UITextField!
    @IBOutlet weak var id: UITextField!
    @IBOutlet weak var name: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
       
    }

    
    @IBAction func selectimg(_ sender: Any)
    {
        let pick = UIImagePickerController()
        pick.sourceType = .photoLibrary
        pick.delegate = self
        self.present(pick, animated: true, completion: nil)
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any])
    {
        let img1 = info[UIImagePickerControllerOriginalImage] as! UIImage
        img.image = img1
        self.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func insert(_ sender: Any)
    {
        let imgdata = UIImageJPEGRepresentation(img.image!, 2)
        let base64str = imgdata?.base64EncodedString(options: Data.Base64EncodingOptions.lineLength64Characters)
        let url = URL(string: "http://localhost/KrimaDB/postJsonInsert.php")
        let dic = ["id":"\(id.text!)","name":"\(name.text!)","address":"\(address.text!)","mon":"\(mon.text!)","img":"\(base64str!)"]
        do
        {
            let jsondata = try JSONSerialization.data(withJSONObject: dic, options: [])
            var request = URLRequest(url: url!)
            request.addValue(String(jsondata.count), forHTTPHeaderField: "Content-Length")
            request.httpBody = jsondata
            request.httpMethod = "POST"
            let session = URLSession.shared
            let datatask = session.dataTask(with: request){ (data1, resp, err) in
                DispatchQueue.main.async {
                    let rep = String(data: data1!, encoding: String.Encoding.utf8)
                    print(rep ?? "dkfd")
                }
            }
            datatask.resume()
        }
        catch
        {}
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
          }


}

